"""Run a local script with the exact USD libraries bundled with Kit 109."""
import os
from pathlib import Path
import runpy
import sys

ROOT = Path(__file__).resolve().parents[1]
KIT = ROOT / 'runtime/kit-app'
USD = next((KIT / 'extscache').glob('omni.usd.libs-*'))
_paths = [USD / 'bin', KIT / 'kit', KIT / 'kit/kernel/plugins']
_handles = [os.add_dll_directory(str(p)) for p in _paths]
os.environ['PATH'] = os.pathsep.join(map(str, _paths)) + os.pathsep + os.environ['PATH']
sys.path.insert(0, str(USD))
sys.argv = sys.argv[1:]
runpy.run_path(sys.argv[0], run_name='__main__')
