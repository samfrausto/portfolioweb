"""Author IYH camera destinations into the integration layer only."""
from pathlib import Path
import json
from pxr import Gf, Sdf, Usd, UsdGeom, UsdLux

ROOT = Path(__file__).resolve().parents[1]
source = Sdf.Layer.FindOrOpen(str(ROOT / 'scenes/Collected_iya_FINAL/iya_dt.usd'))
layer = Sdf.Layer.FindOrOpen(str(ROOT / 'scenes/IYH_navigation.usda'))
for key in ('upAxis', 'metersPerUnit', 'defaultPrim', 'startTimeCode', 'endTimeCode', 'timeCodesPerSecond'):
    if source.pseudoRoot.HasInfo(key):
        layer.pseudoRoot.SetInfo(key, source.pseudoRoot.GetInfo(key))
# Open only the navigation layer while authoring; its class model sublayer is
# temporarily omitted in memory, then restored before saving.
sublayers = list(layer.subLayerPaths)
layer.subLayerPaths = []
stage = Usd.Stage.Open(layer)
UsdGeom.Scope.Define(stage, '/Waypoints')
destinations = json.loads((ROOT / 'scenes/iyh_destinations.json').read_text())
for item in destinations:
    camera = UsdGeom.Camera.Define(stage, '/Waypoints/' + item['id'])
    camera.GetPrim().SetDisplayName(item['label'])
    camera.GetPrim().SetCustomDataByKey('navigation:description', item['description'])
    view = Gf.Matrix4d().SetLookAt(Gf.Vec3d(*item['eye']), Gf.Vec3d(*item['target']), Gf.Vec3d(0,0,1))
    xf = UsdGeom.Xformable(camera)
    xf.MakeMatrixXform().Set(view.GetInverse())
    camera.GetFocalLengthAttr().Set(item.get('focal_length', 20))
    camera.GetHorizontalApertureAttr().Set(36)
    camera.GetVerticalApertureAttr().Set(20.25)
    camera.GetClippingRangeAttr().Set(Gf.Vec2f(1, 100000))
dome = UsdLux.DomeLight.Define(stage, '/NavigationLighting/Fill')
dome.CreateIntensityAttr(20)
dome.CreateColorAttr(Gf.Vec3f(0.83, 0.9, 1.0))
sun = UsdLux.DistantLight.Define(stage, '/NavigationLighting/Key')
sun.CreateIntensityAttr(60)
sun.CreateAngleAttr(12)
UsdGeom.Xformable(sun).MakeMatrixXform().Set(Gf.Matrix4d().SetRotate(Gf.Rotation(Gf.Vec3d(1,0,0), -30)))
stage = None
layer.subLayerPaths = sublayers
layer.Save()
print(f'Authored {len(destinations)} cameras; preserved source Z-up and units metadata.')
