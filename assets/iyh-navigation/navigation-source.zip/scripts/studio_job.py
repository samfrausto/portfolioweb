"""Submit a local, typed studio operation and wait for its matching result."""
from pathlib import Path
import json
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]
job = json.loads(sys.argv[1])
directory = ROOT / 'evidence' / (sys.argv[2] if len(sys.argv)>2 else '')
directory.mkdir(exist_ok=True)
job['id'] = uuid.uuid4().hex
temp = directory / 'studio-command.tmp'
temp.write_text(json.dumps(job))
temp.replace(directory / 'studio-command.json')
deadline = time.monotonic() + 3600
while time.monotonic() < deadline:
    try:
        result = json.loads((directory / 'studio-result.json').read_text())
        if result['id'] == job['id']:
            print(json.dumps(result, indent=2))
            sys.exit(0 if result['ok'] else 1)
    except (FileNotFoundError, json.JSONDecodeError):
        pass
    time.sleep(0.5)
raise TimeoutError('Studio did not complete this job within 3600 seconds')
