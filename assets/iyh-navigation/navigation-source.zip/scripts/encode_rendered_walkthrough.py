"""Encode each completed RTX render exactly once at 60 fps."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
from PIL import Image, ImageStat
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools/python'))
import imageio_ffmpeg
folder=ROOT/'evidence/iyh-building-tour'
record=json.loads((folder/'rendering.json').read_text())
count=len(record['frames'])
assert record['fps']==60 and count==round(record['duration']*60)
dimensions=set()
hashes=[]
brightness=[]
for i in range(count):
    path=folder/f'frame-{i:05d}.png'
    with Image.open(path) as frame:
        dimensions.add(frame.size)
        frame.load()
        sample=frame.convert('RGB').resize((64,36))
        mean=sum(ImageStat.Stat(sample).mean)/3
        assert mean>5, f'Unexpected black or incomplete render: {path.name}'
        brightness.append(mean)
    hashes.append(hashlib.sha256(path.read_bytes()).hexdigest())
assert len(dimensions)==1
width,height=next(iter(dimensions))
assert width>=1920 and height>=1080
ffmpeg=imageio_ffmpeg.get_ffmpeg_exe()
out=ROOT/'portfolio/assets/iyh-navigation'
subprocess.run([ffmpeg,'-y','-hide_banner','-loglevel','warning','-framerate','60','-i',str(folder/'frame-%05d.png'),'-frames:v',str(count),'-vf','crop=1920:1080','-c:v','libx264','-preset','slow','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(out/'iyh-rendered.mp4')],check=True)
subprocess.run([ffmpeg,'-y','-hide_banner','-loglevel','warning','-ss','2','-i',str(out/'iyh-rendered.mp4'),'-frames:v','1',str(out/'iyh-rendered.webp')],check=True)
metadata={'fps':60,'duration_seconds':record['duration'],'frames':count,'output_resolution':[1920,1080],
          'source_resolution':[width,height],'source_frame_hashes':hashes,
          'minimum_frame_mean_brightness':min(brightness),
          'render_seconds':record['render_seconds'],'method':record['method'],
          'edits':'Centered crop to 1920x1080. One rendered image per video frame; no duplicated or interpolated frames introduced by encoding.',
          'shots':record['shots'],'scope':record['scope']}
(out/'iyh-rendered.json').write_text(json.dumps(metadata,indent=2))
print(json.dumps({k:v for k,v in metadata.items() if k!='source_frame_hashes'},indent=2))
