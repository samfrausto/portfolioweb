$ErrorActionPreference = 'Stop'
$kitExe = Join-Path $PSScriptRoot 'runtime\kit-app\kit\kit.exe'
$appConfig = Join-Path $PSScriptRoot 'runtime\kit-app\apps\my_company.my_editor.kit'
$extFolder = Join-Path $PSScriptRoot 'extensions'
$logFile = Join-Path $PSScriptRoot 'evidence\tour-render.log'
$arguments = @(
    ('"' + $appConfig + '"'), '--ext-folder', ('"' + $extFolder + '"'),
    '--enable', 'iyh.navigation_studio', '--no-window',
    ('--/log/file="' + $logFile + '"'), '--/app/iyh/commandNamespace=tour-worker',
    '--/app/window/width=1920', '--/app/window/height=1080',
    '--/app/renderer/skipWhileMinimized=false', '--/app/hangDetector/enabled=false',
    '--/app/viewport/grid/enabled=false', '--/app/iyh/startScene=iyh'
)
Start-Process -FilePath $kitExe -ArgumentList $arguments -WorkingDirectory (Join-Path $PSScriptRoot 'runtime\kit-app') -WindowStyle Hidden -PassThru
