param([ValidateSet('warehouse','iyh')][string]$Scene = 'iyh')
$ErrorActionPreference = 'Stop'
$kitExe = Join-Path $PSScriptRoot 'runtime\kit-app\kit\kit.exe'
$appConfig = Join-Path $PSScriptRoot 'runtime\kit-app\apps\my_company.my_editor.kit'
$extFolder = Join-Path $PSScriptRoot 'extensions'
$logFile = Join-Path $PSScriptRoot ('evidence\studio-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.log')
$arguments = @(
    ('"' + $appConfig + '"'), '--ext-folder', ('"' + $extFolder + '"'),
    '--enable', 'iyh.navigation_studio', ('--/log/file="' + $logFile + '"'),
    '--/app/window/title="IYH Navigation Studio"',
    '--/app/window/width=1600', '--/app/window/height=1000',
    '--/app/hangDetector/enabled=false', '--/app/viewport/grid/enabled=false',
    ('--/app/iyh/startScene=' + $Scene)
)
Start-Process -FilePath $kitExe -ArgumentList $arguments -WorkingDirectory (Join-Path $PSScriptRoot 'runtime\kit-app') -PassThru
