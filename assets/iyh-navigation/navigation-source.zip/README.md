# IYH waypoint navigation

This workspace restores Sam Frausto's Omniverse Kit waypoint project and integrates it with the ACAD 288 class model of Iovine and Young Hall.

## Open the studio

Run `./launch-studio.ps1` in PowerShell. Use `./launch-studio.ps1 -Scene warehouse` for the original test environment. Kit needs its normal NVIDIA shader-cache and application-data access. First-time shader compilation can take several minutes.

The compact viewport interface offers scene switching, saved destinations, Back, Reset view, and Capture. Click an open floor surface to travel smoothly; drag to look around. The destination menu sends the original `teleportToWaypoint` event. Editor reveals Kit's normal editing panels. Three IYH destinations are configured: building overview, interior orientation, and upper courtyard. The warehouse opens at a new Explore camera in an aisle; the original camera destinations are retained.

## Files

- `runtime/kit-app/`: the supplied Kit 109.0.2 packaged application, extracted locally.
- `originals/test-scenes/warehouse.usda`: original warehouse scene recovered from `Downloads/kit-app-template (2).zip`.
- `originals/source/extensions/my_company.waypoint_nav/`: original source archive's extension, which differs from the later packaged version.
- `scenes/Collected_iya_FINAL/`: recovered class collection. This folder is not edited by the navigation companion.
- `scenes/IYH_navigation.usda`: the separate navigation layer over the class scene.
- `scenes/iyh_destinations.json`: camera placement definitions used by `scripts/author_iyh_waypoints.py`.
- `extensions/iyh.navigation_studio/`: desktop authoring and evidence companion.
- `extensions/my_company.waypoint_nav/`: navigation source with small integration fixes: rescan on list requests, publish empty lists, and use camera display names. The same fixes are applied to the extracted runtime extension.
- `originals/packaged-waypoint-nav/`: unchanged snapshot of the original packaged navigation source.
- `originals/packaged-click-travel/`: unchanged snapshot of Sam's original smooth travel extension.
- `extensions/my_company.click_travel/`: adapted click-to-travel and drag-to-look implementation.
- `evidence/`: actual viewport captures, camera metadata, logs, and dependency reports.
- `portfolio/`: local clone of `samfrausto/portfolioweb`.

## Transfer method

The original extension discovers `Camera` children of `/Waypoints`, sends `waypointsList`, receives `teleportToWaypoint`, and assigns the viewport camera. It also supports named Xform markers through settings. The destination schema can be reused in any USD scene; the camera coordinates must be authored for that scene.

The separately packaged `my_company.click_travel` extension already contained smooth camera travel and look events. This restoration retains its `travelClick`, `lookDrag`, `enableTravelMode`, and `disableTravelMode` contract and smoothstep movement. It adds RTX surface picking, Z-up support, Back history, cancellation during scene switches, and a transient session-layer travel camera. Floor picking accepts the observed warehouse ground and IYH ground/upper courtyard elevations; it does not compute a collision-free route. The original browser client was not in the recovered ZIPs. The compact native interface is a replacement, not a recovered original design.

The warehouse uses Y-up and 0.01 meters per unit. The collected IYH root declares Z-up and approximately 1 meter per unit. The integration layer explicitly preserves the source metadata. No physical-distance or building-dimension claim should be inferred from the source's unit metadata: some room assets have inconsistent scale and very large bounds.

## Source recovery and limitations

The supplied `Collected_iya_FINAL-20261022T194101Z-1-002.zip` contains only part of the collection. The main scene and three newly prepared archive parts were recovered from the original shared Google Drive collection on October 22, 2026. `scripts/merge_collection.py` adds missing files without replacing existing files.

The collection still has unresolved references and material compilation errors. `evidence/collection_audit.json` lists missing layer/payload dependencies; it is not a complete texture or MDL validation report. Source material errors include collected MDL modules whose filenames were suffixed while their exported function names were not. These errors are distinct from the waypoint system.

Scene PNG captures come from Omniverse's RTX viewport, with same-name JSON records. UI proof images and demo frames come from Kit's renderer swapchain. Demo recordings replay the same navigation events as the controls; `recording.json` stores the events and real frame timestamps. `scripts/record_navigation_demo.py` encodes those frames without generated imagery. Failed/black diagnostic captures are not portfolio-ready media.

The working integration adds a dome fill and distant key light. Grid and light gizmos are hidden for captures. First scene loading took several minutes while Kit compiled materials. The launch script disables Kit's hang detector so lengthy shader work does not trigger a crash prompt; this does not repair asset errors. Once loaded, the three IYH event/camera checks passed, including the published destination list (`evidence/iyh-validation.json`). This verifies camera selection, not obstacle avoidance or rendering performance.

## Portable source download

The portfolio source ZIP intentionally excludes the NVIDIA runtime and class model. To run it, extract the supplied Kit package into `runtime/kit-app`, place the complete collected class scene at `scenes/Collected_iya_FINAL/iya_dt.usd`, and use `launch-studio.ps1`. The launcher adds the included `extensions` folder. Warehouse switching additionally requires the original warehouse scene prepared as `scenes/warehouse_navigation.usda`; the IYH scene is the default. `scripts/author_iyh_waypoints.py` can regenerate destinations with the bundled Kit Python through `scripts/usd_python.py`.

The portfolio page is `portfolio/projects/iyh-digital-twin.v2.html`; it explains the navigation event flow, camera state, and scene integration alongside rendered and live videos. It is not an embedded live Kit/WebRTC session. Public capture metadata replaces machine-specific paths with project-relative paths and includes original PNG SHA-256 hashes.

The revised page includes Sam's supplied live walkthrough and a separate 60 fps architectural tour. `render_tour` reads camera shots from `scenes/iyh_tour.json`, uses a temporary session-layer camera, waits for 120 renderer frames at each shot opening and 12 renderer frames per subsequent output sample, and restores the original view afterward. `launch-render.ps1` starts an independent background Kit instance with a separate command queue (`tour-worker`). The tour is an authored rendered presentation; the separate live recording demonstrates the navigation interaction. `scripts/encode_rendered_walkthrough.py` packages every rendered frame exactly once; `scripts/prepare_live_walkthrough.py` crops the supplied live recording to the app and retains its original video timing without audio. Public media JSON files document both methods, camera positions, and frame hashes.

## Attribution

Sam's original contribution is the waypoint and smooth click-to-travel extensions and their browser messaging interfaces. The building architecture and interiors were created by the class; the warehouse is an NVIDIA sample environment. The replacement interface, restoration scripts, and IYH integration are subsequent portfolio preparation work developed with Codex assistance. Camera travel is not pathfinding or collision-aware walking. WebRTC event support does not by itself establish a tested browser, Quest, or Vision Pro deployment.
