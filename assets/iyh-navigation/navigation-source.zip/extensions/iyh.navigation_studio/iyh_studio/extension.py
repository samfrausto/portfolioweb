"""Desktop authoring and evidence companion for the original waypoint extension.

Navigation buttons dispatch the original teleportToWaypoint event. Building
layers are never saved by this companion. Captures are real RTX viewport frames.
"""
import asyncio
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import traceback

import carb
import carb.settings
from carb.eventdispatcher import get_eventdispatcher
import omni.ext
import omni.kit.app
import omni.ui as ui
import omni.usd
from omni.kit.viewport.utility import get_active_viewport, get_active_viewport_window, capture_viewport_to_file
from pxr import Gf, Sdf, Usd, UsdGeom, UsdLux

ROOT = Path(__file__).resolve().parents[3]


class NavigationStudio(omni.ext.IExt):
    def on_startup(self, ext_id):
        carb.settings.get_settings().set('/app/viewport/grid/enabled', False)
        carb.settings.get_settings().set('/persistent/app/viewport/displayOptions', 0)
        carb.settings.get_settings().set('/app/window/hideUi', True)
        self._last_job = None
        self._command_dir = ROOT / 'evidence' / (carb.settings.get_settings().get('/app/iyh/commandNamespace') or '')
        self._command_dir.mkdir(exist_ok=True)
        command = self._command_dir / 'studio-command.json'
        if command.exists():
            try:
                self._last_job = json.loads(command.read_text()).get('id')
            except (ValueError, OSError):
                pass
        self._tasks = set()
        self._window = ui.Window('Navigation authoring', width=350, height=650, visible=False)
        self._overlay = None
        self._pointer = None
        self._last_travel = None
        self._travel_sub = get_eventdispatcher().observe_event(observer_name='IYH:travel-status',
            event_name='travelResult', on_event=self._travel_feedback)
        self._name = ui.SimpleStringModel('New destination')
        self._status = ui.SimpleStringModel('Click the floor to move. Drag to look around.')
        self._render_panel()
        self._loop = asyncio.ensure_future(self._commands())
        stage = omni.usd.get_context().get_stage()
        if not stage or not stage.GetRootLayer().realPath:
            self._launch(self._initial_open())
        else:
            get_eventdispatcher().dispatch_event('enableTravelMode')

    async def _initial_open(self):
        for _ in range(120):
            await omni.kit.app.get_app().next_update_async()
        await self.open_scene(carb.settings.get_settings().get('/app/iyh/startScene') or 'warehouse')

    def _launch(self, coro):
        task = asyncio.ensure_future(coro)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    def _waypoints(self):
        stage = omni.usd.get_context().get_stage()
        scope = stage.GetPrimAtPath('/Waypoints') if stage else None
        return list(scope.GetChildren()) if scope and scope.IsValid() else []

    def _render_panel(self):
        window = get_active_viewport_window()
        if not window:
            return
        self._overlay = window.get_frame('iyh.streetview.navigation')
        style = {'Button': {'background_color':0xff36302a,'border_radius':6,'color':0xfff5f3ef,'font_size':14},
                 'Button:hovered': {'background_color':0xff574534},
                 'ComboBox': {'background_color':0xff36302a,'border_radius':6,'color':0xfff5f3ef,'font_size':14},
                 'Label': {'color':0xfff5f3ef,'font_size':14},
                 'StringField': {'background_color':0x00000000,'color':0xffd8ddd9,'font_size':13,'border_width':0}}
        paths = [str(p.GetPath()) for p in self._waypoints() if p.IsA(UsdGeom.Camera)]
        names = ['Destinations'] + [p.rsplit('/',1)[-1].replace('_',' ') for p in paths]
        with self._overlay:
            with ui.ZStack(style=style):
                self._surface = ui.Rectangle(style={'background_color':0x00000000},
                    mouse_pressed_fn=self._pressed, mouse_moved_fn=self._moved,
                    mouse_released_fn=self._released)
                with ui.VStack():
                    ui.Spacer(height=20)
                    with ui.HStack(height=44, spacing=8):
                        ui.Spacer(width=20)
                        ui.Button('IYH', width=70, clicked_fn=lambda:self._launch(self.open_scene('iyh')))
                        ui.Button('Warehouse', width=110, clicked_fn=lambda:self._launch(self.open_scene('warehouse')))
                        with ui.VStack(width=200):
                            ui.Spacer(height=11)
                            combo = ui.ComboBox(0, *names, height=22)
                            combo.model.add_item_changed_fn(lambda m,i:self._destination_selected(m, paths))
                            ui.Spacer(height=11)
                        ui.Spacer()
                        ui.Button('Editor', width=70, clicked_fn=self._toggle_editor)
                        ui.Button('Reset view', width=100, clicked_fn=self._reset_view)
                        ui.Spacer(width=20)
                    ui.Spacer()
                    with ui.HStack(height=44, spacing=8):
                        ui.Spacer()
                        ui.Button('Back', width=65, clicked_fn=lambda:get_eventdispatcher().dispatch_event('travelBack'))
                        with ui.ZStack(width=300):
                            ui.Rectangle(style={'background_color':0xe6211b17,'border_radius':22})
                            ui.Label('Click to move   /   Drag to look', alignment=ui.Alignment.CENTER)
                        ui.Button('Capture', width=85, clicked_fn=lambda:self._launch(self.capture()))
                        ui.Spacer()
                    with ui.HStack(height=26):
                        ui.Spacer()
                        ui.StringField(self._status, read_only=True, width=440, height=24)
                        ui.Spacer()
                    ui.Spacer(height=14)

    def _destination_selected(self, model, paths):
        index = model.get_item_value_model().as_int - 1
        if 0 <= index < len(paths):
            self.teleport(paths[index])

    def _toggle_editor(self):
        settings = carb.settings.get_settings()
        settings.set('/app/window/hideUi', not settings.get('/app/window/hideUi'))

    def _reset_view(self):
        stage = omni.usd.get_context().get_stage()
        path = '/Waypoints/Interior' if stage.GetPrimAtPath('/Waypoints/Interior') else '/Waypoints/Explore'
        if not stage.GetPrimAtPath(path):
            path = '/Waypoints/Floor_Center'
        self.teleport(path)

    def _pressed(self, x, y, button, modifiers):
        if button in (0,1):
            self._pointer = {'start':(x,y),'last':(x,y),'button':button,'drag':False}

    def _moved(self, x, y, *modifiers):
        p = self._pointer
        if not p:
            return
        if abs(x-p['start'][0])+abs(y-p['start'][1]) > 5:
            p['drag'] = True
        if p['drag']:
            get_eventdispatcher().dispatch_event('lookDrag',payload={'dx':x-p['last'][0],'dy':y-p['last'][1]})
        p['last'] = (x,y)

    def _released(self, x, y, button, modifiers):
        p, self._pointer = self._pointer, None
        # Some input devices coalesce move callbacks; never turn a drag into travel.
        if p and not p['drag'] and abs(x-p['start'][0])+abs(y-p['start'][1]) > 5:
            p['drag'] = True
            get_eventdispatcher().dispatch_event('lookDrag',payload={'dx':x-p['start'][0],'dy':y-p['start'][1]})
        if p and button == 0 and not p['drag']:
            width, height = self._surface.computed_width, self._surface.computed_height
            if width > 0 and height > 0:
                nx = (x-self._surface.screen_position_x)/width
                ny = (y-self._surface.screen_position_y)/height
                get_eventdispatcher().dispatch_event('travelClick',payload={'ndc_x':nx,'ndc_y':ny})

    def _travel_feedback(self, event):
        self._last_travel = dict(event.payload)
        self._status.set_value(event.payload.get('message',''))
        if event.payload.get('phase') == 'arrived':
            stage = omni.usd.get_context().get_stage()
            name = 'iyh' if stage.GetPrimAtPath('/Waypoints/Interior') else 'warehouse'
            record = {'scene':name,'captured_at':datetime.now(timezone.utc).isoformat(),**dict(event.payload)}
            (ROOT/'evidence'/f'{name}-travel-result.json').write_text(json.dumps(record,indent=2))

    def refresh(self):
        self._render_panel()
        get_eventdispatcher().dispatch_event('requestWaypoints')

    async def open_scene(self, name):
        filename = {'warehouse': 'warehouse_navigation.usda', 'iyh': 'IYH_navigation.usda'}[name]
        self._status.set_value('Loading ' + filename)
        ok, error = await omni.usd.get_context().open_stage_async(str(ROOT / 'scenes' / filename))
        if not ok:
            raise RuntimeError(error)
        for _ in range(30):
            await omni.kit.app.get_app().next_update_async()
        self.refresh()
        self._reset_view()
        self._status.set_value('Click the floor to move. Drag to look around.')
        self.inspect()

    def teleport(self, path):
        get_eventdispatcher().dispatch_event('disableTravelMode')
        paths = {str(p.GetPath()) for p in self._waypoints() if p.IsA(UsdGeom.Camera)}
        if path not in paths:
            raise ValueError('Not a registered camera waypoint: ' + path)
        get_eventdispatcher().dispatch_event('teleportToWaypoint', payload={'camera_path': path})
        viewport = get_active_viewport()
        if str(viewport.camera_path) != path:
            raise RuntimeError('Original waypoint extension did not switch the camera')
        self._status.set_value('Viewing ' + path.rsplit('/', 1)[-1].replace('_', ' '))
        get_eventdispatcher().dispatch_event('enableTravelMode')
        return {'requested': path, 'active_camera': str(viewport.camera_path), 'verified': True}

    def save_waypoint(self):
        stage = omni.usd.get_context().get_stage()
        allowed = {str((ROOT / 'scenes' / n).resolve()).lower().replace('\\', '/')
                   for n in ('IYH_navigation.usda', 'warehouse_navigation.usda')}
        if stage.GetRootLayer().realPath.lower().replace('\\', '/') not in allowed:
            raise RuntimeError('Open a working scene before authoring waypoints')
        name = re.sub(r'[^A-Za-z0-9_]', '_', self._name.as_string).strip('_')
        if not name or name[0].isdigit():
            raise ValueError('Use a name beginning with a letter')
        path = '/Waypoints/' + name
        if stage.GetPrimAtPath(path):
            raise ValueError('A waypoint with that name already exists')
        source = UsdGeom.Camera(stage.GetPrimAtPath(get_active_viewport().camera_path))
        if not source:
            raise RuntimeError('No active camera')
        with Usd.EditContext(stage, stage.GetRootLayer()):
            UsdGeom.Scope.Define(stage, '/Waypoints')
            camera = UsdGeom.Camera.Define(stage, path)
            camera.SetFromCamera(source.GetCamera(Usd.TimeCode.Default()))
            camera.GetPrim().SetDisplayName(self._name.as_string)
        stage.GetRootLayer().Save()
        self.refresh()
        self._status.set_value('Saved ' + path)

    def inspect(self):
        stage = omni.usd.get_context().get_stage()
        if not stage:
            return {}
        bbox = UsdGeom.BBoxCache(Usd.TimeCode.Default(), ['default', 'render'], useExtentsHint=True)
        prims = []
        for prim in stage.GetPseudoRoot().GetChildren():
            children = prim.GetChildren() if str(prim.GetPath()) == '/World' else [prim]
            for child in children:
                bound = bbox.ComputeWorldBound(child).ComputeAlignedRange()
                prims.append({'path': str(child.GetPath()), 'type': child.GetTypeName(),
                              'min': list(bound.GetMin()), 'max': list(bound.GetMax())})
        result = {'stage': stage.GetRootLayer().realPath, 'meters_per_unit': UsdGeom.GetStageMetersPerUnit(stage),
                  'up_axis': str(UsdGeom.GetStageUpAxis(stage)),
                  'prim_count': sum(1 for _ in stage.Traverse()), 'objects': prims,
                  'waypoints': [str(p.GetPath()) for p in self._waypoints()],
                  'camera': str(get_active_viewport().camera_path)}
        (ROOT / 'evidence/current_stage.json').write_text(json.dumps(result, indent=2))
        return result

    async def capture(self, name=None):
        viewport = get_active_viewport()
        name = re.sub(r'[^A-Za-z0-9_-]', '_', name or datetime.now().strftime('capture_%Y%m%d_%H%M%S'))
        path = ROOT / 'evidence' / (name + '.png')
        for _ in range(30):
            await omni.kit.app.get_app().next_update_async()
        capture = capture_viewport_to_file(viewport, str(path))
        await capture.wait_for_result()
        stage = omni.usd.get_context().get_stage()
        prim = stage.GetPrimAtPath(viewport.camera_path)
        record = {'file': path.name, 'captured_at': datetime.now(timezone.utc).isoformat(),
                  'stage': stage.GetRootLayer().realPath, 'camera': str(viewport.camera_path),
                  'world_transform': str(UsdGeom.Xformable(prim).ComputeLocalToWorldTransform(Usd.TimeCode.Default())),
                  'source': 'Unmodified RTX viewport capture; no generated imagery.'}
        path.with_suffix('.json').write_text(json.dumps(record, indent=2))
        self._status.set_value('Captured ' + path.name)
        return record

    async def _commands(self):
        """Local workspace job queue for repeatable capture/validation, no network port."""
        command = self._command_dir / 'studio-command.json'
        while True:
            await asyncio.sleep(0.5)
            if not command.exists():
                continue
            try:
                job = json.loads(command.read_text())
                if job['id'] == self._last_job:
                    continue
                self._last_job = job['id']
                op = job['op']
                if op == 'open':
                    await self.open_scene(job['scene'])
                    result = self.inspect()
                elif op == 'inspect':
                    result = self.inspect()
                elif op == 'validate':
                    results = []
                    published = []
                    observer = get_eventdispatcher().observe_event(observer_name='NavigationStudio:validation',
                        event_name='waypointsList', on_event=lambda event: published.extend(event.payload['waypoints']))
                    get_eventdispatcher().dispatch_event('requestWaypoints')
                    original_camera = str(get_active_viewport().camera_path)
                    for prim in self._waypoints():
                        if prim.IsA(UsdGeom.Camera):
                            results.append(self.teleport(str(prim.GetPath())))
                    get_active_viewport().camera_path = original_camera
                    result = {'tested_at': datetime.now(timezone.utc).isoformat(),
                              'stage': omni.usd.get_context().get_stage().GetRootLayer().realPath,
                              'event': 'teleportToWaypoint', 'checks': results,
                              'published_waypoints': published}
                    observer = None
                    if {w['path'] for w in published} != {r['requested'] for r in results}:
                        raise RuntimeError('Published waypoint list does not match the scene cameras')
                    report_name = 'iyh-validation.json' if 'IYH_navigation' in result['stage'] else 'warehouse-validation.json'
                    (ROOT / 'evidence' / report_name).write_text(json.dumps(result, indent=2))
                elif op == 'author':
                    stage = omni.usd.get_context().get_stage()
                    if Path(stage.GetRootLayer().realPath).name != 'IYH_navigation.usda':
                        raise ValueError('Open the IYH working layer before authoring destinations')
                    destinations = json.loads((ROOT / 'scenes/iyh_destinations.json').read_text())
                    with Usd.EditContext(stage, stage.GetRootLayer()):
                        for item in destinations:
                            camera = UsdGeom.Camera.Define(stage, '/Waypoints/' + item['id'])
                            camera.GetPrim().SetDisplayName(item['label'])
                            view = Gf.Matrix4d().SetLookAt(Gf.Vec3d(*item['eye']), Gf.Vec3d(*item['target']), Gf.Vec3d(0,0,1))
                            UsdGeom.Xformable(camera).MakeMatrixXform().Set(view.GetInverse())
                            camera.GetFocalLengthAttr().Set(item.get('focal_length', 20))
                            camera.GetHorizontalApertureAttr().Set(36)
                            camera.GetVerticalApertureAttr().Set(20.25)
                            camera.GetClippingRangeAttr().Set(Gf.Vec2f(1, 100000))
                    stage.GetRootLayer().Save()
                    self.refresh()
                    result = {'authored': len(destinations)}
                elif op == 'warehouse_start':
                    stage = omni.usd.get_context().get_stage()
                    if Path(stage.GetRootLayer().realPath).name != 'warehouse_navigation.usda':
                        raise ValueError('Open the warehouse working scene')
                    with Usd.EditContext(stage, stage.GetRootLayer()):
                        camera = UsdGeom.Camera.Define(stage, '/Waypoints/Explore')
                        matrix = Gf.Matrix4d().SetLookAt(Gf.Vec3d(120,200,535), Gf.Vec3d(-880,200,535), Gf.Vec3d(0,1,0)).GetInverse()
                        UsdGeom.Xformable(camera).MakeMatrixXform().Set(matrix)
                        camera.GetFocalLengthAttr().Set(18)
                        camera.GetHorizontalApertureAttr().Set(20.955)
                        camera.GetVerticalApertureAttr().Set(13.097)
                        camera.GetClippingRangeAttr().Set(Gf.Vec2f(1,100000))
                    stage.GetRootLayer().Save()
                    self.refresh()
                    result = self.teleport('/Waypoints/Explore')
                elif op == 'teleport':
                    result = self.teleport(job['path'])
                elif op == 'travel':
                    self._last_travel = None
                    get_eventdispatcher().dispatch_event('travelClick',payload={'ndc_x':job['x'],'ndc_y':job['y']})
                    import time
                    deadline = time.monotonic()+8
                    while time.monotonic()<deadline:
                        await omni.kit.app.get_app().next_update_async()
                        if self._last_travel and (self._last_travel.get('phase')=='arrived' or not self._last_travel.get('success')):
                            break
                    result = self._last_travel or {'success':False,'message':'No travel event response'}
                elif op == 'look':
                    get_eventdispatcher().dispatch_event('lookDrag',payload={'dx':job['dx'],'dy':job['dy']})
                    result = {'camera':str(get_active_viewport().camera_path)}
                elif op == 'record':
                    result = await self.record_demo(job)
                elif op == 'render_demo':
                    result = await self.render_demo(job)
                elif op == 'render_tour':
                    result = await self.render_tour(job)
                elif op == 'find_scene_objects':
                    stage = omni.usd.get_context().get_stage()
                    cache = UsdGeom.BBoxCache(Usd.TimeCode.Default(), ['default','render'])
                    result = []
                    for prim in stage.Traverse():
                        if str(prim.GetPath()).startswith(job.get('root','/')) and any(word in prim.GetName().lower() for word in job['terms']):
                            bounds = cache.ComputeWorldBound(prim).ComputeAlignedRange()
                            if bounds.IsEmpty():
                                continue
                            result.append({'path':str(prim.GetPath()),'min':list(bounds.GetMin()),'max':list(bounds.GetMax())})
                            if len(result) >= 150:
                                break
                elif op == 'validate_travel_controls':
                    stage = omni.usd.get_context().get_stage()
                    def pose():
                        return UsdGeom.Camera(stage.GetPrimAtPath(get_active_viewport().camera_path)).ComputeLocalToWorldTransform(Usd.TimeCode.Default())
                    before = pose()
                    arrived = self._last_travel
                    if not arrived or arrived.get('phase') != 'arrived':
                        raise ValueError('Run a successful travel first')
                    get_eventdispatcher().dispatch_event('lookDrag',payload={'dx':10,'dy':0})
                    looked = pose()
                    get_eventdispatcher().dispatch_event('lookDrag',payload={'dx':-10,'dy':0})
                    self._last_travel = None
                    get_eventdispatcher().dispatch_event('travelClick',payload={'ndc_x':.5,'ndc_y':0})
                    for _ in range(120):
                        await omni.kit.app.get_app().next_update_async()
                        if self._last_travel:
                            break
                    rejected = self._last_travel
                    unchanged = (pose().ExtractTranslation()-before.ExtractTranslation()).GetLength()<1e-6
                    get_eventdispatcher().dispatch_event('travelBack')
                    restored = (pose().ExtractTranslation()-Gf.Vec3d(*arrived['start'])).GetLength()<1e-6
                    result = {'scene':Path(stage.GetRootLayer().realPath).name,
                              'look_changes_orientation':looked!=before,
                              'look_preserves_position':(looked.ExtractTranslation()-before.ExtractTranslation()).GetLength()<1e-6,
                              'sky_click_rejected':bool(rejected and not rejected.get('success')),
                              'rejected_click_preserves_position':unchanged,
                              'back_restores_position':restored}
                    result['passed'] = all(value for key,value in result.items() if key!='scene')
                    (ROOT/'evidence/interaction-validation.json').write_text(json.dumps(result,indent=2))
                elif op == 'capture':
                    result = await self.capture(job['name'])
                elif op == 'presentation':
                    stage = omni.usd.get_context().get_stage()
                    with Usd.EditContext(stage, stage.GetRootLayer()):
                        dome = UsdLux.DomeLight.Define(stage, '/NavigationLighting/Fill')
                        dome.CreateIntensityAttr(20)
                        dome.CreateColorAttr(Gf.Vec3f(0.83, 0.9, 1.0))
                        sun = UsdLux.DistantLight.Define(stage, '/NavigationLighting/Key')
                        sun.CreateIntensityAttr(60)
                        sun.CreateAngleAttr(12)
                        UsdGeom.Xformable(sun).MakeMatrixXform().Set(Gf.Matrix4d().SetRotate(Gf.Rotation(Gf.Vec3d(1,0,0), -30)))
                    stage.GetRootLayer().Save()
                    result = {'lighting': 'Presentation dome and key; source class layers unchanged'}
                elif op == 'reload':
                    stage = omni.usd.get_context().get_stage()
                    name = 'iyh' if Path(stage.GetRootLayer().realPath).name == 'IYH_navigation.usda' else 'warehouse'
                    await omni.usd.get_context().close_stage_async()
                    await self.open_scene(name)
                    result = self.inspect()
                else:
                    raise ValueError('Unknown job operation')
                output = {'id': job['id'], 'ok': True, 'result': result}
            except asyncio.CancelledError:
                raise
            except Exception:
                output = {'id': self._last_job, 'ok': False, 'error': traceback.format_exc()}
                carb.log_error(output['error'])
            (self._command_dir / 'studio-result.json').write_text(json.dumps(output, indent=2))

    async def render_tour(self, job):
        """Render authored architectural shots without altering the user's camera."""
        import time
        import struct
        stage = omni.usd.get_context().get_stage()
        viewport = get_active_viewport()
        if Path(stage.GetRootLayer().realPath).name != 'IYH_navigation.usda':
            raise ValueError('Open IYH before rendering its building tour')
        shots = job.get('shots') or json.loads((ROOT/'scenes/iyh_tour.json').read_text())
        preview = bool(job.get('preview'))
        folder = ROOT/'evidence'/('iyh-tour-preview' if preview else 'iyh-building-tour')
        folder.mkdir(exist_ok=True)
        original_path, original_resolution = str(viewport.camera_path), viewport.resolution
        fps, frames, started = 60, [], time.perf_counter()
        total = len(shots)*2 if preview else sum(round(s['duration']*fps) for s in shots)
        get_eventdispatcher().dispatch_event('disableTravelMode')
        try:
            with Usd.EditContext(stage,stage.GetSessionLayer()):
                camera = UsdGeom.Camera.Define(stage,'/NavigationRenderCamera')
                camera.GetHorizontalApertureAttr().Set(36)
                camera.GetVerticalApertureAttr().Set(20.25)
                camera.GetClippingRangeAttr().Set(Gf.Vec2f(1,100000))
                transform = UsdGeom.Xformable(camera).MakeMatrixXform()
            viewport.camera_path = '/NavigationRenderCamera'
            viewport.resolution = (1920,1080)
            for shot_index, shot in enumerate(shots):
                count = 2 if preview else round(shot['duration']*fps)
                for local_frame in range(count):
                    phase = local_frame/(count-1)
                    # Cubic easing gives each architectural shot a gentle start and stop.
                    blend = phase*phase*(3-2*phase)
                    eye = Gf.Vec3d(*shot['eye']) + (Gf.Vec3d(*shot.get('end_eye',shot['eye']))-Gf.Vec3d(*shot['eye']))*blend
                    target = Gf.Vec3d(*shot['target']) + (Gf.Vec3d(*shot.get('end_target',shot['target']))-Gf.Vec3d(*shot['target']))*blend
                    matrix = Gf.Matrix4d().SetLookAt(eye,target,Gf.Vec3d(0,0,1)).GetInverse()
                    with Usd.EditContext(stage,stage.GetSessionLayer()):
                        transform.Set(matrix)
                        camera.GetFocalLengthAttr().Set(shot.get('focal_length',20))
                    await viewport.wait_for_rendered_frames(120 if local_frame==0 else 12)
                    index = len(frames)
                    path = folder/f'frame-{index:05d}.png'
                    capture = capture_viewport_to_file(viewport,str(path))
                    await capture.wait_for_result()
                    frames.append({'frame':index,'time':index/fps,'shot':shot['name'],'camera_matrix':[list(row) for row in matrix]})
                    if index%30==0 or local_frame==count-1:
                        (folder/'progress.json').write_text(json.dumps({'frame':len(frames),'total':total,'shot':shot['name'],'elapsed_seconds':time.perf_counter()-started}))
            resolution = list(struct.unpack('>II',(folder/'frame-00000.png').read_bytes()[16:24]))
            record = {'fps':fps,'duration':len(frames)/fps,'resolution':resolution,'shots':shots,'frames':frames,
                      'render_seconds':time.perf_counter()-started,
                      'method':'Frame-by-frame RTX viewport render; 120 warmup frames per shot and 12 settled renderer frames per output frame. No optical-flow interpolation.',
                      'scope':'Authored architectural camera tour of the class digital twin; live navigation is demonstrated in the separate interaction recording.'}
            (folder/'rendering.json').write_text(json.dumps(record,indent=2))
            (folder/'progress.json').write_text(json.dumps({'frame':len(frames),'total':total,'complete':True,'elapsed_seconds':record['render_seconds']}))
            return {'frames':len(frames),'render_seconds':record['render_seconds'],'folder':str(folder)}
        finally:
            viewport.camera_path = original_path
            viewport.resolution = original_resolution
            with Usd.EditContext(stage,stage.GetSessionLayer()):
                stage.RemovePrim('/NavigationRenderCamera')
            get_eventdispatcher().dispatch_event('enableTravelMode')
            self._status.set_value('Click the floor to move. Drag to look around.')

    async def render_demo(self, job):
        """Render a validated travel route frame by frame, independent of live FPS."""
        import time
        stage = omni.usd.get_context().get_stage()
        viewport = get_active_viewport()
        if Path(stage.GetRootLayer().realPath).name != 'IYH_navigation.usda':
            raise ValueError('Open IYH before rendering its saved travel route')
        route = json.loads((ROOT/'evidence/user-navigation-route.json').read_text())
        if not route.get('success') or route.get('phase') != 'arrived':
            raise ValueError('A verified live travel route is required')
        original_path = str(viewport.camera_path)
        camera = UsdGeom.Camera(stage.GetPrimAtPath(original_path))
        original = camera.ComputeLocalToWorldTransform(Usd.TimeCode.Default())
        original_resolution = viewport.resolution
        start, target = Gf.Vec3d(*route['start']), Gf.Vec3d(*route['target'])
        up = Gf.Vec3d(0,0,1)
        forward = original.TransformDir(Gf.Vec3d(0,0,-1)).GetNormalized()
        fps, duration = 60, 7
        folder = ROOT/'evidence/iyh-rendered'
        folder.mkdir(exist_ok=True)
        frames = []
        get_eventdispatcher().dispatch_event('disableTravelMode')
        render_camera = None
        started = time.perf_counter()
        def ease(t):
            t = max(0.0, min(1.0,t))
            return t*t*(3-2*t)
        try:
            with Usd.EditContext(stage,stage.GetSessionLayer()):
                render_camera = UsdGeom.Camera.Define(stage,'/NavigationRenderCamera')
                render_camera.SetFromCamera(camera.GetCamera(Usd.TimeCode.Default()))
                transform = UsdGeom.Xformable(render_camera).MakeMatrixXform()
            viewport.camera_path = '/NavigationRenderCamera'
            viewport.resolution = (1920,1080)
            self._status.set_value('Rendering showcase frames')
            # Warm the actual scene and its shaders before sampling any frame.
            await viewport.wait_for_rendered_frames(120)
            for frame in range(round(fps*duration)):
                t = frame/fps
                position = start + (target-start)*ease((t-1)/.55)
                yaw = 35*ease((t-2.2)/2.2)-35*ease((t-4.8)/1.7)
                facing = Gf.Rotation(up,yaw).TransformDir(forward)
                matrix = Gf.Matrix4d().SetLookAt(position,position+facing,up).GetInverse()
                with Usd.EditContext(stage,stage.GetSessionLayer()):
                    transform.Set(matrix)
                await viewport.wait_for_rendered_frames(12)
                path = folder/f'frame-{frame:05d}.png'
                capture = capture_viewport_to_file(viewport,str(path))
                await capture.wait_for_result()
                frames.append({'frame':frame,'time':t,'camera_matrix':[list(row) for row in matrix]})
                if frame%30==0:
                    (folder/'progress.json').write_text(json.dumps({'frame':frame+1,'total':round(fps*duration),'elapsed_seconds':time.perf_counter()-started}))
                if job.get('preview') and frame==0:
                    return {'preview':str(path)}
            import struct
            actual_resolution = list(struct.unpack('>II',(folder/'frame-00000.png').read_bytes()[16:24]))
            record = {'fps':fps,'duration':duration,'resolution':actual_resolution,
                      'method':'Frame-by-frame RTX viewport render; 120 warmup frames and 12 settled renderer frames per output frame. No optical-flow interpolation.',
                      'route':route,'frames':frames,'render_seconds':time.perf_counter()-started,
                      'scope':'Rendered presentation of a verified live travel route, not a live performance benchmark'}
            (folder/'rendering.json').write_text(json.dumps(record,indent=2))
            (folder/'progress.json').write_text(json.dumps({'frame':len(frames),'total':len(frames),'complete':True,'elapsed_seconds':record['render_seconds']}))
            return {'frames':len(frames),'render_seconds':record['render_seconds'],'folder':str(folder)}
        finally:
            viewport.camera_path = original_path
            viewport.resolution = original_resolution
            with Usd.EditContext(stage,stage.GetSessionLayer()):
                stage.RemovePrim('/NavigationRenderCamera')
            get_eventdispatcher().dispatch_event('enableTravelMode')
            self._status.set_value('Click the floor to move. Drag to look around.')

    async def record_demo(self, job):
        """Record real rendered application frames while replaying navigation events."""
        import time
        import omni.kit.renderer_capture
        name = re.sub(r'[^A-Za-z0-9_-]', '_', job['name'])
        folder = ROOT / 'evidence' / name
        folder.mkdir(exist_ok=True)
        renderer = omni.kit.renderer_capture.acquire_renderer_capture_interface()
        app = omni.kit.app.get_app()
        events = sorted(job.get('events', []), key=lambda event:event['at'])
        frames, sent = [], []
        start = time.perf_counter()
        next_frame = 0.0
        duration = min(float(job.get('duration', 6)), 20)
        while True:
            elapsed = time.perf_counter()-start
            while events and elapsed >= events[0]['at']:
                event = events.pop(0)
                if event['event'] not in ('travelClick','lookDrag','travelBack'):
                    raise ValueError('Unsupported demo event')
                get_eventdispatcher().dispatch_event(event['event'], payload=event.get('payload', {}))
                sent.append({**event,'actual_time':elapsed})
            if elapsed >= duration:
                break
            if elapsed >= next_frame:
                path = folder / f'frame-{len(frames):05d}.png'
                renderer.capture_next_frame_swapchain(str(path))
                frames.append({'file':path.name,'time':elapsed})
                next_frame = elapsed + 1/24
            await app.next_update_async()
        for _ in range(10):
            await app.next_update_async()
        renderer.wait_async_capture()
        record = {'duration':duration,'frames':frames,'events':sent,
                  'capture':'Omniverse renderer swapchain, real-time event replay',
                  'last_travel':self._last_travel}
        (folder/'recording.json').write_text(json.dumps(record,indent=2))
        return {'frames':len(frames),'folder':str(folder),'last_travel':self._last_travel}

    def on_shutdown(self):
        self._travel_sub = None
        if self._overlay:
            self._overlay.clear()
        if getattr(self, '_loop', None):
            self._loop.cancel()
        for task in self._tasks:
            task.cancel()
        self._window.destroy()
        self._window = None
