"""Sam Frausto's click-to-travel event interface, adapted for Y/Z-up scenes.

Retains travelClick, lookDrag and the original 0.55-second smoothstep movement.
Integration changes: world transforms, RTX surface picking, session-layer camera,
scene lifecycle cleanup, and completion feedback. Original source is preserved.
"""
import asyncio
import math
import time
import carb
import carb.events
from carb.eventdispatcher import get_eventdispatcher
import omni.ext
import omni.kit.app
import omni.usd
import omni.kit.raycast.query as rq
from omni.kit.viewport.utility import get_active_viewport
from pxr import Gf, Usd, UsdGeom
try:
    import omni.kit.livestream.messaging as messaging
except ImportError:
    messaging = None

TRAVEL_CAM_PATH = '/TravelCamera'
TRAVEL_DURATION = 0.55
LOOK_SENSITIVITY = 0.25


def screen_ray(stage, viewport, x, y):
    if not all(math.isfinite(v) and 0 <= v <= 1 for v in (x, y)):
        raise ValueError('Click inside the viewport')
    camera = UsdGeom.Camera(stage.GetPrimAtPath(viewport.camera_path))
    world = camera.ComputeLocalToWorldTransform(Usd.TimeCode.Default())
    aperture = camera.GetHorizontalApertureAttr().Get()
    width, height = viewport.resolution
    vertical = aperture * height / max(width, 1)
    ray = Gf.Vec3d((x-.5)*aperture, (.5-y)*vertical, -camera.GetFocalLengthAttr().Get())
    return world.ExtractTranslation(), world.TransformDir(ray).GetNormalized()


class ClickTravelExtension(omni.ext.IExt):
    def on_startup(self, ext_id):
        self._enabled = False
        self._travel_task = None
        self._history = []
        self._subs = []
        self._generation = 0
        ed = get_eventdispatcher()
        for event in ('travelResult', 'travelModeState'):
            if messaging:
                messaging.register_event_type_to_send(event)
            omni.kit.app.register_event_alias(carb.events.type_from_string(event), event)
        for event, callback in (('enableTravelMode', self._enable), ('disableTravelMode', self._disable),
                                ('travelClick', self._click), ('lookDrag', self._look), ('travelBack', self._back)):
            omni.kit.app.register_event_alias(carb.events.type_from_string(event), event)
            self._subs.append(ed.observe_event(observer_name='ClickTravel:'+event, event_name=event, on_event=callback))
        self._stage_sub = omni.usd.get_context().get_stage_event_stream().create_subscription_to_pop(self._stage_event)

    def _stage_event(self, event):
        if event.type in (int(omni.usd.StageEventType.CLOSING), int(omni.usd.StageEventType.OPENED)):
            self._cancel()
            self._history.clear()

    def _cancel(self):
        self._generation += 1
        if self._travel_task:
            self._travel_task.cancel()
            self._travel_task = None

    def _enable(self, event=None):
        self._enabled = True
        get_eventdispatcher().dispatch_event('travelModeState', payload={'enabled': True})

    def _disable(self, event=None):
        self._enabled = False
        self._cancel()
        get_eventdispatcher().dispatch_event('travelModeState', payload={'enabled': False})

    def _adopt_view(self):
        stage = omni.usd.get_context().get_stage()
        vp = get_active_viewport()
        if not stage or not vp:
            return None
        source = UsdGeom.Camera(stage.GetPrimAtPath(vp.camera_path))
        if not source:
            return None
        world = source.ComputeLocalToWorldTransform(Usd.TimeCode.Default())
        with Usd.EditContext(stage, stage.GetSessionLayer()):
            camera = UsdGeom.Camera.Define(stage, TRAVEL_CAM_PATH)
            camera.SetFromCamera(source.GetCamera(Usd.TimeCode.Default()))
            UsdGeom.Xformable(camera).MakeMatrixXform().Set(world)
        vp.camera_path = TRAVEL_CAM_PATH
        return stage, camera, world

    def _write(self, stage, camera, matrix):
        with Usd.EditContext(stage, stage.GetSessionLayer()):
            UsdGeom.Xformable(camera).MakeMatrixXform().Set(matrix)

    def _look(self, event):
        if not self._enabled or (self._travel_task and not self._travel_task.done()):
            return
        dx, dy = float(event.payload.get('dx', 0)), float(event.payload.get('dy', 0))
        if not math.isfinite(dx) or not math.isfinite(dy):
            return
        adopted = self._adopt_view()
        if not adopted:
            return
        stage, camera, world = adopted
        up = Gf.Vec3d(0,0,1) if UsdGeom.GetStageUpAxis(stage) == 'Z' else Gf.Vec3d(0,1,0)
        forward = world.TransformDir(Gf.Vec3d(0,0,-1)).GetNormalized()
        forward = Gf.Rotation(up, -dx*LOOK_SENSITIVITY).TransformDir(forward)
        pitch = math.degrees(math.asin(max(-1, min(1, Gf.Dot(forward, up)))))
        desired = max(-85, min(85, pitch-dy*LOOK_SENSITIVITY))
        right = Gf.Cross(forward, up).GetNormalized()
        forward = Gf.Rotation(right, desired-pitch).TransformDir(forward)
        pos = world.ExtractTranslation()
        self._write(stage, camera, Gf.Matrix4d().SetLookAt(pos, pos+forward, up).GetInverse())

    def _click(self, event):
        if not self._enabled:
            self._result(False, 'Travel is paused')
            return
        if self._travel_task and not self._travel_task.done():
            return
        try:
            x, y = float(event.payload['ndc_x']), float(event.payload['ndc_y'])
        except (KeyError, TypeError, ValueError):
            self._result(False, 'Click inside the viewport')
            return
        self._travel_task = asyncio.ensure_future(self._travel(x, y, self._generation))

    async def _travel(self, x, y, generation):
        try:
            adopted = self._adopt_view()
            if not adopted:
                self._result(False, 'The scene is still loading')
                return
            stage, camera, world = adopted
            origin, direction = screen_ray(stage, get_active_viewport(), x, y)
            axis = 2 if UsdGeom.GetStageUpAxis(stage) == 'Z' else 1
            if direction[axis] >= -.015:
                self._result(False, 'Click a floor surface below the horizon')
                return
            future = asyncio.get_running_loop().create_future()
            def picked(ray, result):
                if not future.done():
                    future.set_result(result)
            rq.acquire_raycast_query_interface().submit_raycast_query(rq.Ray(tuple(origin), tuple(direction)), picked)
            result = await asyncio.wait_for(future, 5)
            if generation != self._generation:
                return
            if not result.valid or abs(result.normal[axis]) < .7:
                self._result(False, 'Choose an open floor surface')
                return
            hit = Gf.Vec3d(*result.hit_position)
            # The provided IYH assets use centimeter-like geometry despite root
            # meter metadata. Match observed floor elevations, not physical claims.
            floors = [0.0, 532.0] if axis == 2 else [0.0]
            floor = min(floors, key=lambda value: abs(value-hit[axis]))
            if abs(hit[axis]-floor) > 45:
                self._result(False, 'Choose the floor, rather than furniture')
                return
            eye = 180.0 if axis == 2 else 200.0
            target = Gf.Vec3d(hit)
            target[axis] = floor + eye
            if (target-origin).GetLength() > 5000:
                self._result(False, 'Choose a closer point')
                return
            self._history.append(Gf.Matrix4d(world))
            self._history = self._history[-20:]
            self._result(True, 'Moving', phase='moving', target=list(target))
            t0 = time.perf_counter()
            previous = t0
            elapsed = 0.0
            samples = []
            while generation == self._generation:
                await omni.kit.app.get_app().next_update_async()
                now = time.perf_counter()
                elapsed += min(now-previous, 1/30)
                previous = now
                t = min(elapsed/TRAVEL_DURATION, 1.0)
                alpha = t*t*(3-2*t)
                pos = origin + (target-origin)*alpha
                frame = Gf.Matrix4d(world)
                frame.SetTranslateOnly(pos)
                self._write(stage, camera, frame)
                samples.append(list(pos))
                if t >= 1:
                    break
            if generation == self._generation:
                self._result(True, 'Click the floor to continue', phase='arrived', start=list(origin),
                             target=list(target), duration=time.perf_counter()-t0,
                             samples=samples, surface=result.get_target_usd_path())
        except asyncio.CancelledError:
            raise
        except Exception as error:
            carb.log_warn('[click_travel] '+str(error))
            self._result(False, 'Could not reach that point; try nearby floor')

    def _back(self, event=None):
        self._cancel()
        adopted = self._adopt_view()
        if adopted and self._history:
            stage, camera, _ = adopted
            self._write(stage, camera, self._history.pop())
            self._result(True, 'Returned to the previous view', phase='back')

    def _result(self, success, message, **data):
        get_eventdispatcher().dispatch_event('travelResult', payload={'success':success,'message':message,**data})

    def on_shutdown(self):
        self._enabled = False
        self._cancel()
        self._stage_sub = None
        self._subs.clear()
