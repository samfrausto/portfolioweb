"""
Click-to-Travel extension.

Receives normalised screen coordinates from the browser, casts a ray from the
viewport camera through that point, intersects with the ground plane (Y=0),
and teleports the camera to the hit location at a fixed eye height.

Uses a dedicated /TravelCamera prim and switches vp_api.camera_path to it,
avoiding conflicts with omni.kit.manipulator.camera which overwrites direct
xformOp writes on the active camera.

Also handles right-drag look-around by rotating the active camera prim.
"""

import math
import time
import asyncio

import omni.ext
import omni.usd
import omni.kit.app
import carb
import carb.events
import carb.settings
from carb.eventdispatcher import get_eventdispatcher
from pxr import Usd, UsdGeom, Gf, Sdf

try:
    import omni.kit.livestream.messaging as messaging
except ImportError:
    messaging = None
    carb.log_warn("[click_travel] omni.kit.livestream.messaging not available")

GROUND_Y = 0.0
EYE_HEIGHT = 200.0
MAX_TRAVEL_DISTANCE = 50000.0
COI_DISTANCE = 1000.0
LOOK_SENSITIVITY = 0.25
TRAVEL_DURATION = 0.55
TRAVEL_CAM_PATH = "/TravelCamera"

START_TRANSLATE = Gf.Vec3d(120, 200, -180)
START_ROTATE = Gf.Vec3f(-25, 90, 0)

OUTGOING_EVENTS = ["travelResult", "travelModeState"]
INCOMING_EVENTS = {
    "enableTravelMode": "_on_enable",
    "disableTravelMode": "_on_disable",
    "travelClick": "_on_travel_click",
    "lookDrag": "_on_look_drag",
}


def _screen_to_world_ray(stage, viewport_api, ndc_x: float, ndc_y: float):
    cam_prim = stage.GetPrimAtPath(viewport_api.camera_path)
    if not cam_prim.IsValid():
        carb.log_warn("[click_travel] camera prim invalid")
        return None, None

    cam = UsdGeom.Camera(cam_prim)
    focal = cam.GetFocalLengthAttr().Get() if cam.GetFocalLengthAttr().HasValue() else 24.0
    h_ap = cam.GetHorizontalApertureAttr().Get() if cam.GetHorizontalApertureAttr().HasValue() else 20.955
    v_ap = cam.GetVerticalApertureAttr().Get() if cam.GetVerticalApertureAttr().HasValue() else 15.2908

    try:
        res = viewport_api.resolution
        if res and len(res) >= 2 and res[0] > 0 and res[1] > 0:
            effective_v_ap = h_ap / (float(res[0]) / float(res[1]))
        else:
            effective_v_ap = v_ap
    except Exception:
        effective_v_ap = v_ap

    lx = (ndc_x - 0.5) * h_ap
    ly = (0.5 - ndc_y) * effective_v_ap
    lz = -focal
    local_dir = Gf.Vec3d(lx, ly, lz).GetNormalized()

    xformable = UsdGeom.Xformable(cam_prim)
    world_xform = xformable.ComputeLocalToWorldTransform(Usd.TimeCode.Default())
    cam_pos = world_xform.ExtractTranslation()
    world_dir = world_xform.TransformDir(local_dir)
    length = Gf.Vec3d(world_dir).GetLength()
    if length < 1e-9:
        return None, None
    world_dir = Gf.Vec3d(world_dir) / length

    carb.log_warn(
        f"[click_travel] ray  ndc=({ndc_x:.3f},{ndc_y:.3f})  "
        f"cam=({cam_pos[0]:.0f},{cam_pos[1]:.0f},{cam_pos[2]:.0f})  "
        f"dir=({world_dir[0]:.3f},{world_dir[1]:.3f},{world_dir[2]:.3f})"
    )
    return Gf.Vec3d(cam_pos), Gf.Vec3d(world_dir)


def _intersect_ground_plane(origin, direction, ground_y: float = GROUND_Y):
    if abs(direction[1]) < 1e-6:
        return None
    t = (ground_y - origin[1]) / direction[1]
    if t < 0:
        return None
    hit = Gf.Vec3d(
        origin[0] + direction[0] * t,
        ground_y,
        origin[2] + direction[2] * t,
    )
    if (hit - origin).GetLength() > MAX_TRAVEL_DISTANCE:
        return None
    return hit


def _read_cam_transform(stage, cam_path):
    """Read translate and rotateXYZ from a camera prim."""
    prim = stage.GetPrimAtPath(cam_path)
    if not prim.IsValid():
        return None, None
    xf = UsdGeom.Xformable(prim)
    pos = None
    rot = None
    for op in xf.GetOrderedXformOps():
        if op.GetOpName() == "xformOp:translate":
            v = op.Get()
            pos = Gf.Vec3d(v[0], v[1], v[2])
        elif op.GetOpName() == "xformOp:rotateXYZ":
            v = op.Get()
            rot = Gf.Vec3f(v[0], v[1], v[2])
    return pos, rot


class ClickTravelExtension(omni.ext.IExt):
    def on_startup(self, ext_id):
        self._enabled = False
        self._animating = False
        self._msg_subs = []
        self._stage_event_sub = None

        settings = carb.settings.get_settings()
        self._ground_y = settings.get("/app/click_travel/ground_y") or GROUND_Y
        self._eye_height = settings.get("/app/click_travel/eye_height") or EYE_HEIGHT

        self._register_messaging()
        asyncio.ensure_future(self._deferred_init())

    # ------------------------------------------------------------------
    # Initialization
    # ------------------------------------------------------------------

    async def _deferred_init(self):
        app = omni.kit.app.get_app()
        for _ in range(120):
            await app.next_update_async()
            ctx = omni.usd.get_context()
            stage = ctx.get_stage()
            if stage:
                break
        else:
            return

        for _ in range(30):
            await app.next_update_async()

        self._ensure_travel_camera()

        ctx = omni.usd.get_context()
        self._stage_event_sub = ctx.get_stage_event_stream().create_subscription_to_pop(
            self._on_stage_event
        )

    def _on_stage_event(self, event):
        if event.type == int(omni.usd.StageEventType.OPENED):
            asyncio.ensure_future(self._on_stage_opened())

    async def _on_stage_opened(self):
        app = omni.kit.app.get_app()
        for _ in range(30):
            await app.next_update_async()
        self._ensure_travel_camera()

    def _ensure_travel_camera(self):
        """Create /TravelCamera if it doesn't exist, with starting transform."""
        stage = omni.usd.get_context().get_stage()
        if stage is None:
            return

        prim = stage.GetPrimAtPath(TRAVEL_CAM_PATH)
        if prim.IsValid():
            return

        cam_prim = stage.DefinePrim(TRAVEL_CAM_PATH, "Camera")
        cam = UsdGeom.Camera(cam_prim)
        cam.GetFocalLengthAttr().Set(18.0)
        cam.GetHorizontalApertureAttr().Set(20.955)
        cam.GetVerticalApertureAttr().Set(15.2908)
        cam.GetClippingRangeAttr().Set(Gf.Vec2f(1, 10000000))

        xf = UsdGeom.Xformable(cam_prim)
        xf.AddTranslateOp().Set(START_TRANSLATE)
        xf.AddRotateXYZOp().Set(START_ROTATE)

        cam_prim.CreateAttribute(
            "omni:kit:centerOfInterest", Sdf.ValueTypeNames.Vector3d
        ).Set(Gf.Vec3d(0, 0, -COI_DISTANCE))

        carb.log_warn(f"[click_travel] Created {TRAVEL_CAM_PATH}")

    # ------------------------------------------------------------------
    # Messaging registration
    # ------------------------------------------------------------------

    def _register_messaging(self):
        ed = get_eventdispatcher()

        for name in OUTGOING_EVENTS:
            if messaging:
                messaging.register_event_type_to_send(name)
            omni.kit.app.register_event_alias(
                carb.events.type_from_string(name), name
            )

        for name, method_name in INCOMING_EVENTS.items():
            omni.kit.app.register_event_alias(
                carb.events.type_from_string(name), name
            )
            handler = getattr(self, method_name)
            self._msg_subs.append(
                ed.observe_event(
                    observer_name=f"ClickTravel:{name}",
                    event_name=name,
                    on_event=handler,
                )
            )

    # ------------------------------------------------------------------
    # Mode toggling
    # ------------------------------------------------------------------

    def _on_enable(self, event=None):
        self._enabled = True
        # Force a known travel camera on enable so clicks raycast from a stable pose.
        stage = omni.usd.get_context().get_stage()
        if stage:
            self._ensure_travel_camera()
            try:
                from omni.kit.viewport.utility import get_active_viewport
                vp = get_active_viewport()
                if vp is not None:
                    vp.camera_path = TRAVEL_CAM_PATH
            except ImportError:
                pass
        carb.log_warn("[click_travel] >>> Travel mode ENABLED")
        get_eventdispatcher().dispatch_event(
            "travelModeState", payload={"enabled": True}
        )

    def _on_disable(self, event=None):
        self._enabled = False
        carb.log_warn("[click_travel] >>> Travel mode DISABLED")
        get_eventdispatcher().dispatch_event(
            "travelModeState", payload={"enabled": False}
        )

    # ------------------------------------------------------------------
    # Look-around (right-drag from browser)
    # ------------------------------------------------------------------

    def _on_look_drag(self, event):
        dx = 0.0
        dy = 0.0
        if hasattr(event, "payload"):
            dx = event.payload.get("dx", 0.0)
            dy = event.payload.get("dy", 0.0)

        carb.log_warn(f"[click_travel] >>> lookDrag received dx={dx:.1f} dy={dy:.1f}")

        if dx == 0.0 and dy == 0.0:
            return

        ctx = omni.usd.get_context()
        stage = ctx.get_stage()
        if stage is None:
            return

        try:
            from omni.kit.viewport.utility import get_active_viewport
            vp = get_active_viewport()
        except ImportError:
            return
        if vp is None:
            return

        cam_prim = stage.GetPrimAtPath(vp.camera_path)
        if not cam_prim.IsValid():
            return

        xformable = UsdGeom.Xformable(cam_prim)
        rot_op = None
        cur_rot = None
        for op in xformable.GetOrderedXformOps():
            if op.GetOpName() == "xformOp:rotateXYZ":
                cur_rot = op.Get()
                rot_op = op
                break

        if cur_rot is None or rot_op is None:
            carb.log_warn(f"[click_travel] lookDrag: no rotateXYZ op on {vp.camera_path}")
            return

        pitch = max(-89.0, min(89.0, cur_rot[0] - float(dy) * LOOK_SENSITIVITY))
        yaw = cur_rot[1] - float(dx) * LOOK_SENSITIVITY
        rot_op.Set(Gf.Vec3f(pitch, yaw, cur_rot[2]))

        coi_attr = cam_prim.GetAttribute("omni:kit:centerOfInterest")
        if coi_attr and coi_attr.IsValid():
            coi_attr.Set(Gf.Vec3d(0, 0, -COI_DISTANCE))

    # ------------------------------------------------------------------
    # Click handler
    # ------------------------------------------------------------------

    def _on_travel_click(self, event):
        carb.log_warn(f"[click_travel] >>> travelClick received, enabled={self._enabled}")
        if not self._enabled:
            self._send_result(False, "Travel mode is not active")
            return
        if self._animating:
            return

        ndc_x = None
        ndc_y = None
        if hasattr(event, "payload"):
            ndc_x = event.payload.get("ndc_x")
            ndc_y = event.payload.get("ndc_y")
        if ndc_x is None or ndc_y is None:
            self._send_result(False, "Missing ndc_x / ndc_y")
            return

        ctx = omni.usd.get_context()
        stage = ctx.get_stage()
        if stage is None:
            self._send_result(False, "No stage")
            return

        try:
            from omni.kit.viewport.utility import get_active_viewport
            vp = get_active_viewport()
        except ImportError:
            self._send_result(False, "No viewport")
            return
        if vp is None:
            self._send_result(False, "No viewport")
            return

        origin, direction = _screen_to_world_ray(stage, vp, float(ndc_x), float(ndc_y))
        if origin is None:
            self._send_result(False, "Could not compute ray")
            return

        if direction[1] >= 0:
            # If the camera happens to look above the horizon, bias ray downward
            # so travel mode still works without manual camera repitching.
            direction = Gf.Vec3d(direction[0], -abs(direction[1]), direction[2])
            carb.log_warn("[click_travel] Ray pointed upward, adjusted downward")

        hit = _intersect_ground_plane(origin, direction, self._ground_y)
        if hit is None:
            self._send_result(False, "No ground intersection")
            carb.log_warn("[click_travel] No ground hit")
            return

        target = Gf.Vec3d(hit[0], self._ground_y + self._eye_height, hit[2])

        # Read current camera transform so the travel camera starts at the current view
        cur_pos, cur_rot = _read_cam_transform(stage, str(vp.camera_path))
        if cur_pos is None:
            cur_pos = START_TRANSLATE
        if cur_rot is None:
            cur_rot = START_ROTATE

        # Ensure travel camera exists and set its starting transform to match current view
        travel_prim = stage.GetPrimAtPath(TRAVEL_CAM_PATH)
        if not travel_prim.IsValid():
            self._ensure_travel_camera()
            travel_prim = stage.GetPrimAtPath(TRAVEL_CAM_PATH)

        xf = UsdGeom.Xformable(travel_prim)
        for op in xf.GetOrderedXformOps():
            if op.GetOpName() == "xformOp:translate":
                op.Set(cur_pos)
            elif op.GetOpName() == "xformOp:rotateXYZ":
                op.Set(cur_rot)

        # Switch viewport to travel camera, then animate it
        vp.camera_path = TRAVEL_CAM_PATH

        carb.log_warn(
            f"[click_travel] Animating {TRAVEL_CAM_PATH} from "
            f"({cur_pos[0]:.0f},{cur_pos[1]:.0f},{cur_pos[2]:.0f}) to "
            f"({target[0]:.0f},{target[1]:.0f},{target[2]:.0f})"
        )
        asyncio.ensure_future(self._animate_travel(stage, travel_prim, cur_pos, target))

    # ------------------------------------------------------------------
    # Smooth animation on the travel camera prim
    # ------------------------------------------------------------------

    async def _animate_travel(self, stage, travel_prim, start_pos, target_pos):
        self._animating = True
        self._send_result(True, "Traveling")

        xf = UsdGeom.Xformable(travel_prim)
        translate_op = None
        for op in xf.GetOrderedXformOps():
            if op.GetOpName() == "xformOp:translate":
                translate_op = op
                break

        if translate_op is None:
            self._animating = False
            return

        app = omni.kit.app.get_app()
        t0 = time.perf_counter()

        while True:
            await app.next_update_async()
            elapsed = time.perf_counter() - t0
            t = min(elapsed / TRAVEL_DURATION, 1.0)
            alpha = t * t * (3.0 - 2.0 * t)

            new_pos = Gf.Vec3d(
                start_pos[0] + (target_pos[0] - start_pos[0]) * alpha,
                start_pos[1] + (target_pos[1] - start_pos[1]) * alpha,
                start_pos[2] + (target_pos[2] - start_pos[2]) * alpha,
            )
            translate_op.Set(new_pos)

            if t >= 1.0:
                break

        coi_attr = travel_prim.GetAttribute("omni:kit:centerOfInterest")
        if coi_attr and coi_attr.IsValid():
            coi_attr.Set(Gf.Vec3d(0, 0, -COI_DISTANCE))

        self._animating = False
        carb.log_warn(f"[click_travel] Arrived at ({target_pos[0]:.0f}, {target_pos[1]:.0f}, {target_pos[2]:.0f})")

    # ------------------------------------------------------------------
    # Feedback
    # ------------------------------------------------------------------

    def _send_result(self, success: bool, message: str = ""):
        get_eventdispatcher().dispatch_event(
            "travelResult",
            payload={"success": success, "message": message},
        )

    def on_shutdown(self):
        self._enabled = False
        self._stage_event_sub = None
        self._msg_subs.clear()
