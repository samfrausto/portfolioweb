"""
Waypoint Navigation extension.

Scans the USD stage for Camera prims under /Waypoints and exposes them to the
browser via WebRTC messaging.  The browser sends teleport requests back over
the same channel; this extension moves the active viewport camera accordingly.
"""

import math
import omni.ext
import omni.usd
import omni.kit.app
import carb
import carb.events
import carb.settings
from carb.eventdispatcher import get_eventdispatcher
from pxr import Usd, UsdGeom, Gf
import asyncio

try:
    import omni.kit.livestream.messaging as messaging
except ImportError:
    messaging = None
    carb.log_warn("[waypoint_nav] omni.kit.livestream.messaging not available")

WAYPOINTS_SCOPE = "/Waypoints"
COI_DISTANCE = 1000.0
WAYPOINT_PROXY_CAMERA_PATH = "/WaypointProxyCamera"

OUTGOING_EVENTS = ["waypointsList"]
INCOMING_EVENTS = {
    "requestWaypoints": "_on_request_waypoints",
    "teleportToWaypoint": "_on_teleport_request",
}


def _get_camera_focal_length(camera_prim):
    cam = UsdGeom.Camera(camera_prim)
    fl_attr = cam.GetFocalLengthAttr()
    if fl_attr and fl_attr.HasValue():
        return fl_attr.Get()
    return 18.0


def _forward_from_euler_xyz(pitch_deg, yaw_deg, roll_deg):
    """Compute the world-space forward vector (-Z in camera space) from Euler XYZ."""
    pitch = math.radians(pitch_deg)
    yaw = math.radians(yaw_deg)
    fx = -math.sin(yaw) * math.cos(pitch)
    fy = math.sin(pitch)
    fz = -math.cos(yaw) * math.cos(pitch)
    return Gf.Vec3d(fx, fy, fz)


class WaypointNavExtension(omni.ext.IExt):
    def on_startup(self, ext_id):
        self._waypoints = []
        self._stage_event_sub = None
        self._msg_subs = []

        self._register_messaging()
        asyncio.ensure_future(self._deferred_init())

    def _register_messaging(self):
        """Register event types with the livestream messaging layer."""
        ed = get_eventdispatcher()

        for name in OUTGOING_EVENTS:
            if messaging:
                messaging.register_event_type_to_send(name)
            omni.kit.app.register_event_alias(
                carb.events.type_from_string(name), name
            )

        for name, method_name in INCOMING_EVENTS.items():
            omni.kit.app.register_event_alias(
                carb.events.type_from_string(name), name
            )
            handler = getattr(self, method_name)
            self._msg_subs.append(
                ed.observe_event(
                    observer_name=f"WaypointNav:{name}",
                    event_name=name,
                    on_event=handler,
                )
            )

    async def _deferred_init(self):
        """Wait for the stage to be loaded before scanning for waypoints."""
        app = omni.kit.app.get_app()
        for _ in range(60):
            await app.next_update_async()
            ctx = omni.usd.get_context()
            stage = ctx.get_stage()
            if stage and stage.GetPrimAtPath(WAYPOINTS_SCOPE).IsValid():
                break

        self._scan_waypoints()
        self._send_waypoints()

        ctx = omni.usd.get_context()
        self._stage_event_sub = ctx.get_stage_event_stream().create_subscription_to_pop(
            self._on_stage_event
        )

    def _on_stage_event(self, event):
        if event.type == int(omni.usd.StageEventType.OPENED):
            asyncio.ensure_future(self._on_stage_opened())

    async def _on_stage_opened(self):
        app = omni.kit.app.get_app()
        for _ in range(10):
            await app.next_update_async()
        self._scan_waypoints()
        self._send_waypoints()

    def _scan_waypoints(self):
        """Find Camera prims under /Waypoints and optional marker Xforms by name."""
        self._waypoints = []
        ctx = omni.usd.get_context()
        stage = ctx.get_stage()
        if stage is None:
            return

        scope_prim = stage.GetPrimAtPath(WAYPOINTS_SCOPE)
        if scope_prim.IsValid():
            for child in scope_prim.GetChildren():
                if child.IsA(UsdGeom.Camera):
                    name = child.GetName().replace("_", " ")
                    self._waypoints.append({
                        "name": name,
                        "path": str(child.GetPath()),
                    })
        else:
            carb.log_warn(f"[waypoint_nav] No scope found at {WAYPOINTS_SCOPE}")

        marker_names = self._get_xform_waypoint_names()
        if marker_names:
            seen = {w["path"] for w in self._waypoints}
            for prim in stage.Traverse():
                if not prim.IsValid() or not prim.IsA(UsdGeom.Xform):
                    continue
                if prim.GetName() not in marker_names:
                    continue
                path = str(prim.GetPath())
                if path in seen:
                    continue
                self._waypoints.append({
                    "name": prim.GetName().replace("_", " "),
                    "path": path,
                })
                seen.add(path)

        carb.log_warn(f"[waypoint_nav] Found {len(self._waypoints)} waypoints: "
                       f"{[w['name'] for w in self._waypoints]}")

    # ------------------------------------------------------------------
    # Messaging (Kit <-> Browser)
    # ------------------------------------------------------------------

    def _send_waypoints(self):
        """Push the waypoint list to the browser."""
        if not self._waypoints:
            carb.log_warn("[waypoint_nav] _send_waypoints called but list is empty")
            return
        get_eventdispatcher().dispatch_event(
            "waypointsList",
            payload={"waypoints": self._waypoints},
        )
        carb.log_warn(f"[waypoint_nav] Sent {len(self._waypoints)} waypoints to browser")

    def _on_request_waypoints(self, event=None):
        """Browser asked for the waypoint list."""
        carb.log_warn("[waypoint_nav] >>> requestWaypoints received from browser")
        self._send_waypoints()

    def _on_teleport_request(self, event):
        """Browser asked to teleport to a waypoint."""
        carb.log_warn(f"[waypoint_nav] >>> teleportToWaypoint received, "
                       f"payload={event.payload if hasattr(event, 'payload') else 'NO PAYLOAD'}")
        camera_path = None
        if hasattr(event, "payload"):
            camera_path = event.payload.get("camera_path")
        if not camera_path:
            carb.log_warn("[waypoint_nav] teleportToWaypoint missing camera_path")
            return
        self._teleport_to(camera_path)

    # ------------------------------------------------------------------
    # Camera teleport
    # ------------------------------------------------------------------

    def _teleport_to(self, camera_path: str):
        """Switch viewport to waypoint camera, or proxy camera for marker Xforms."""
        ctx = omni.usd.get_context()
        stage = ctx.get_stage()
        if stage is None:
            return

        wp_prim = stage.GetPrimAtPath(camera_path)
        if not wp_prim.IsValid():
            carb.log_warn(f"[waypoint_nav] Camera not found: {camera_path}")
            return

        try:
            from omni.kit.viewport.utility import get_active_viewport
            vp_api = get_active_viewport()
        except ImportError:
            carb.log_error("[waypoint_nav] Could not get active viewport")
            return

        if vp_api is None:
            return

        if wp_prim.IsA(UsdGeom.Camera):
            vp_api.camera_path = camera_path
            carb.log_warn(f"[waypoint_nav] Switched viewport camera to {camera_path}")
            return

        if not wp_prim.IsA(UsdGeom.Xform):
            carb.log_warn(f"[waypoint_nav] Unsupported waypoint prim type at {camera_path}")
            return

        proxy = self._ensure_proxy_camera(stage)
        if not proxy:
            return
        if not self._copy_xform_to_proxy(stage, wp_prim, proxy):
            return
        vp_api.camera_path = proxy
        carb.log_warn(f"[waypoint_nav] Switched viewport to marker waypoint {camera_path}")

    def _get_xform_waypoint_names(self):
        settings = carb.settings.get_settings()
        names = settings.get("/app/waypoint_nav/xform_waypoint_names")
        if isinstance(names, (list, tuple)):
            return {str(name).strip() for name in names if str(name).strip()}
        if isinstance(names, str):
            return {name.strip() for name in names.split(",") if name.strip()}
        return set()

    def _ensure_proxy_camera(self, stage):
        proxy_prim = stage.GetPrimAtPath(WAYPOINT_PROXY_CAMERA_PATH)
        if not proxy_prim.IsValid():
            proxy_prim = stage.DefinePrim(WAYPOINT_PROXY_CAMERA_PATH, "Camera")
            if not proxy_prim.IsValid():
                carb.log_warn("[waypoint_nav] Could not create proxy camera")
                return None

        cam = UsdGeom.Camera(proxy_prim)
        cam.GetFocalLengthAttr().Set(18.0)
        cam.GetHorizontalApertureAttr().Set(20.955)
        cam.GetVerticalApertureAttr().Set(15.2908)
        cam.GetClippingRangeAttr().Set(Gf.Vec2f(1, 10000000))

        xf = UsdGeom.Xformable(proxy_prim)
        ops = xf.GetOrderedXformOps()
        has_t = any(op.GetOpName() == "xformOp:translate" for op in ops)
        has_r = any(op.GetOpName() == "xformOp:rotateXYZ" for op in ops)
        if not has_t:
            xf.AddTranslateOp().Set(Gf.Vec3d(0, 0, 0))
        if not has_r:
            xf.AddRotateXYZOp().Set(Gf.Vec3f(0, 0, 0))
        return WAYPOINT_PROXY_CAMERA_PATH

    def _copy_xform_to_proxy(self, stage, source_prim, proxy_path):
        src = UsdGeom.Xformable(source_prim)
        src_world = src.ComputeLocalToWorldTransform(Usd.TimeCode.Default())
        translate = src_world.ExtractTranslation()
        rot = src_world.ExtractRotation().Decompose(
            Gf.Vec3d(1, 0, 0), Gf.Vec3d(0, 1, 0), Gf.Vec3d(0, 0, 1)
        )
        pitch = float(rot[0])
        yaw = float(rot[1])
        roll = float(rot[2])

        proxy_prim = stage.GetPrimAtPath(proxy_path)
        if not proxy_prim.IsValid():
            carb.log_warn("[waypoint_nav] Proxy camera missing")
            return False

        xf = UsdGeom.Xformable(proxy_prim)
        for op in xf.GetOrderedXformOps():
            if op.GetOpName() == "xformOp:translate":
                op.Set(Gf.Vec3d(translate[0], translate[1], translate[2]))
            elif op.GetOpName() == "xformOp:rotateXYZ":
                op.Set(Gf.Vec3f(pitch, yaw, roll))
        return True

    def on_shutdown(self):
        self._stage_event_sub = None
        self._msg_subs.clear()
        self._waypoints = []
